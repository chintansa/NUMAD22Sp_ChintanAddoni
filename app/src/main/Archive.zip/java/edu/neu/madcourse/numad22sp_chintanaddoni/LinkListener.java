package edu.neu.madcourse.numad22sp_chintanaddoni;

public interface LinkListener {

    void onItemClick(int position);

}
